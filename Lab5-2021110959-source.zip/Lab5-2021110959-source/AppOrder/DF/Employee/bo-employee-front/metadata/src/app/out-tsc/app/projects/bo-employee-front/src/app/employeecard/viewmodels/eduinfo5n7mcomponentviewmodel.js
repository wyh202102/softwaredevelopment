import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ViewModel, NgCommand } from '@farris/devkit';
import { Observable } from 'rxjs';
var ɵ0 = { type: 'string' };
var Eduinfo5n7mComponentViewmodel = /** @class */ (function (_super) {
    tslib_1.__extends(Eduinfo5n7mComponentViewmodel, _super);
    function Eduinfo5n7mComponentViewmodel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bindingPath = '/eduInfos';
        _this.dom = {
            "eduinfo-5n7m-dataGrid": {
                "type": "DataGrid",
                "resourceId": "eduinfo-5n7m-dataGrid",
                "visible": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": true
                },
                "id": "eduinfo-5n7m-dataGrid",
                "size": {},
                "readonly": {
                    "useQuote": false,
                    "isExpression": false,
                    "value": false
                },
                "fields": [
                    {
                        "type": "GridField",
                        "resourceId": "schoolName_03445c2d_x1dt",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "schoolName_03445c2d_x1dt",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "schoolName",
                            "fullPath": "SchoolName",
                            "isExpression": false,
                            "value": "schoolName"
                        },
                        "dataField": "schoolName",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学校名称",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "schoolName_03445c2d_nufh",
                            "defaultI18nValue": "学校名称",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "schoolName_03445c2d_nufh",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "schoolName",
                                "fullPath": "SchoolName",
                                "isExpression": false,
                                "value": "schoolName"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "timeInterval_f0c2cb3d_oajz",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "timeInterval_f0c2cb3d_oajz",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "timeInterval",
                            "fullPath": "TimeInterval",
                            "isExpression": false,
                            "value": "timeInterval"
                        },
                        "dataField": "timeInterval",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "时间区间",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "timeInterval_f0c2cb3d_waop",
                            "defaultI18nValue": "时间区间",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "timeInterval_f0c2cb3d_waop",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "timeInterval",
                                "fullPath": "TimeInterval",
                                "isExpression": false,
                                "value": "timeInterval"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "studyType_afaddce9_ov6q",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "studyType_afaddce9_ov6q",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "studyType",
                            "fullPath": "StudyType",
                            "isExpression": false,
                            "value": "studyType"
                        },
                        "dataField": "studyType",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学习形式",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "studyType_afaddce9_5ozc",
                            "defaultI18nValue": "学习形式",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "studyType_afaddce9_5ozc",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "studyType",
                                "fullPath": "StudyType",
                                "isExpression": false,
                                "value": "studyType"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "education_a617eb0b_1ggh",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "education_a617eb0b_1ggh",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "education",
                            "fullPath": "Education",
                            "isExpression": false,
                            "value": "education"
                        },
                        "dataField": "education",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学历",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "education_a617eb0b_qwl1",
                            "defaultI18nValue": "学历",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "education_a617eb0b_qwl1",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "education",
                                "fullPath": "Education",
                                "isExpression": false,
                                "value": "education"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "major_e7f1b580_qr7r",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "major_e7f1b580_qr7r",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "major",
                            "fullPath": "Major",
                            "isExpression": false,
                            "value": "major"
                        },
                        "dataField": "major",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "专业",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "major_e7f1b580_lv8a",
                            "defaultI18nValue": "专业",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "major_e7f1b580_lv8a",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "major",
                                "fullPath": "Major",
                                "isExpression": false,
                                "value": "major"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "eduSystem_3417c999_2vup",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "eduSystem_3417c999_2vup",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "eduSystem",
                            "fullPath": "EduSystem",
                            "isExpression": false,
                            "value": "eduSystem"
                        },
                        "dataField": "eduSystem",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学制",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "eduSystem_3417c999_yw5h",
                            "defaultI18nValue": "学制",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "eduSystem_3417c999_yw5h",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "eduSystem",
                                "fullPath": "EduSystem",
                                "isExpression": false,
                                "value": "eduSystem"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "degree_553e6f70_81mn",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "degree_553e6f70_81mn",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "degree",
                            "fullPath": "Degree",
                            "isExpression": false,
                            "value": "degree"
                        },
                        "dataField": "degree",
                        "dataType": "string",
                        "multiLanguage": false,
                        "caption": "学位",
                        "editor": {
                            "type": "TextBox",
                            "isTextArea": true,
                            "resourceId": "degree_553e6f70_ffvk",
                            "defaultI18nValue": "学位",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "degree_553e6f70_ffvk",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "degree",
                                "fullPath": "Degree",
                                "isExpression": false,
                                "value": "degree"
                            },
                            "disable": false,
                            "maxLength": 36,
                            "isPassword": false,
                            "enableViewPassword": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "blur",
                        "formatter": {
                            "type": "none"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "isFirstDegree_6e18be6a_uqsh",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "isFirstDegree_6e18be6a_uqsh",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "isFirstDegree",
                            "fullPath": "IsFirstDegree",
                            "isExpression": false,
                            "value": "isFirstDegree"
                        },
                        "dataField": "isFirstDegree",
                        "dataType": "boolean",
                        "multiLanguage": false,
                        "caption": "是否第一学历",
                        "editor": {
                            "type": "CheckBox",
                            "resourceId": "isFirstDegree_6e18be6a_rpvu",
                            "defaultI18nValue": "是否第一学历",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "isFirstDegree_6e18be6a_rpvu",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "isFirstDegree",
                                "fullPath": "IsFirstDegree",
                                "isExpression": false,
                                "value": "isFirstDegree"
                            },
                            "disable": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "change",
                        "formatter": {
                            "type": "boolean",
                            "trueText": "是",
                            "falseText": "否"
                        }
                    },
                    {
                        "type": "GridField",
                        "resourceId": "isHighest_f326b212_0hiz",
                        "visible": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": true
                        },
                        "id": "isHighest_f326b212_0hiz",
                        "size": {
                            "width": 120
                        },
                        "readonly": {
                            "useQuote": false,
                            "isExpression": false,
                            "value": false
                        },
                        "binding": {
                            "type": "Form",
                            "path": "isHighest",
                            "fullPath": "IsHighest",
                            "isExpression": false,
                            "value": "isHighest"
                        },
                        "dataField": "isHighest",
                        "dataType": "boolean",
                        "multiLanguage": false,
                        "caption": "是否最高学历",
                        "editor": {
                            "type": "CheckBox",
                            "resourceId": "isHighest_f326b212_olqq",
                            "defaultI18nValue": "是否最高学历",
                            "visible": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": true
                            },
                            "id": "isHighest_f326b212_olqq",
                            "size": {},
                            "readonly": {
                                "useQuote": false,
                                "isExpression": false,
                                "value": false
                            },
                            "binding": {
                                "type": "Form",
                                "path": "isHighest",
                                "fullPath": "IsHighest",
                                "isExpression": false,
                                "value": "isHighest"
                            },
                            "disable": false
                        },
                        "draggable": false,
                        "frozen": "none",
                        "sortable": true,
                        "aggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "groupAggregate": {
                            "type": "none",
                            "formatter": {
                                "type": "none"
                            }
                        },
                        "linkedLabelEnabled": false,
                        "updateOn": "change",
                        "formatter": {
                            "type": "boolean",
                            "trueText": "是",
                            "falseText": "否"
                        }
                    }
                ],
                "multiSelect": false,
                "showLineNumber": false,
                "lineNumberTitle": "#",
                "groupTotalText": "Total",
                "filterable": false,
                "groupable": false,
                "rowClass": ""
            }
        };
        return _this;
    }
    Eduinfo5n7mComponentViewmodel.prototype.rootviewmodelAddItem1 = function (commandParam) { return; };
    Eduinfo5n7mComponentViewmodel.prototype.rootviewmodelRemoveItem1 = function (commandParam) { return; };
    tslib_1.__decorate([
        NgCommand({
            name: 'rootviewmodelAddItem1',
            params: {}
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], Eduinfo5n7mComponentViewmodel.prototype, "rootviewmodelAddItem1", null);
    tslib_1.__decorate([
        NgCommand({
            name: 'rootviewmodelRemoveItem1',
            params: {
                id: '{DATA~/eduinfo-5n7m-component/eduInfos/id}',
                successMsg: ''
            },
            paramDescriptions: {
                id: ɵ0,
                successMsg: { type: '' }
            }
        }),
        tslib_1.__metadata("design:type", Function),
        tslib_1.__metadata("design:paramtypes", [Object]),
        tslib_1.__metadata("design:returntype", Observable)
    ], Eduinfo5n7mComponentViewmodel.prototype, "rootviewmodelRemoveItem1", null);
    Eduinfo5n7mComponentViewmodel = tslib_1.__decorate([
        Injectable()
    ], Eduinfo5n7mComponentViewmodel);
    return Eduinfo5n7mComponentViewmodel;
}(ViewModel));
export { Eduinfo5n7mComponentViewmodel };
export { ɵ0 };
