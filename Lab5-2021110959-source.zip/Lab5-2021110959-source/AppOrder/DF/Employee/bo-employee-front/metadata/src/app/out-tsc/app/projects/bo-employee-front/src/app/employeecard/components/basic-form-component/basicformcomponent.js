import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS, ComponentManagerService } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { LookupGridComponent } from '@farris/ui-lookup';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { BasicFormViewmodel } from '../../viewmodels/basicformviewmodel';
import { EmployeeRepository } from '../../models/employeerepository';
import { LangService } from '../../lang/lang-pipe';
import { BasicFormViewmodelForm } from '../../viewmodels/form/basicformviewmodelform';
import { BasicFormViewmodelUIState } from '../../viewmodels/uistate/basicformviewmodeluistate';
var BasicFormComponent = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormComponent, _super);
    function BasicFormComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, componentManagerService, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.componentManagerService = componentManagerService;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-struct-wrapper ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.FieldSetTitle755dc17e8c674d5cb0f97a02001496d0 = _this.langService.transform("755dc17e-8c67-4d5c-b0f9-7a02001496d0", _this.lang, "个人信息");
        _this.FieldSetCollapseText755dc17e8c674d5cb0f97a02001496d0 = _this.langService.transform("FieldSet/755dc17e-8c67-4d5c-b0f9-7a02001496d0/collapseText", _this.lang, "");
        _this.FieldSetExpandText755dc17e8c674d5cb0f97a02001496d0 = _this.langService.transform("FieldSet/755dc17e-8c67-4d5c-b0f9-7a02001496d0/expandText", _this.lang, "");
        _this.FieldSetTitlecc3a1b0c463e4021bdead19d10d55d5c = _this.langService.transform("cc3a1b0c-463e-4021-bdea-d19d10d55d5c", _this.lang, "工作信息");
        _this.FieldSetCollapseTextcc3a1b0c463e4021bdead19d10d55d5c = _this.langService.transform("FieldSet/cc3a1b0c-463e-4021-bdea-d19d10d55d5c/collapseText", _this.lang, "");
        _this.FieldSetExpandTextcc3a1b0c463e4021bdead19d10d55d5c = _this.langService.transform("FieldSet/cc3a1b0c-463e-4021-bdea-d19d10d55d5c/expandText", _this.lang, "");
        _this.FieldSetTitle5eee9be8c42d46a0a8f50fab2a62b8a7 = _this.langService.transform("5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7", _this.lang, "联系方式");
        _this.FieldSetCollapseText5eee9be8c42d46a0a8f50fab2a62b8a7 = _this.langService.transform("FieldSet/5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7/collapseText", _this.lang, "");
        _this.FieldSetExpandText5eee9be8c42d46a0a8f50fab2a62b8a7 = _this.langService.transform("FieldSet/5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7/expandText", _this.lang, "");
        _this.SectionbasicformsectionMainTitle = _this.langService.transform("Section/basic-form-section/mainTitle", _this.lang, "基本信息");
        _this.SectionbasicformsectionSubTitle = _this.langService.transform("Section/basic-form-section/subTitle", _this.lang, "");
        _this.LookupEditorganizationOrganizationShortName58a39191yswjDialogTitle = _this.langService.transform("LookupEdit/organization_Organization_ShortName_58a39191_yswj/dialogTitle", _this.lang, "");
        _this.organization_Organization_ShortName_58a39191_yswj_PlaceHolder = _this.langService.transform("LookupEdit/organization_Organization_ShortName_58a39191_yswj/placeHolder", _this.lang, "");
        _this.gender_58ff12cc_9oofEnumData = [
            {
                "name": _this.langService.transform("EnumField/gender_58ff12cc_9oof/enumData/men", _this.lang, "男"),
                "value": "men"
            },
            {
                "name": _this.langService.transform("EnumField/gender_58ff12cc_9oof/enumData/women", _this.lang, "女"),
                "value": "women"
            }
        ];
        _this.gender_58ff12cc_9oof_PlaceHolder = _this.langService.transform("EnumField/gender_58ff12cc_9oof/placeHolder", _this.lang, "");
        _this.category_351d2443_g9ilEnumData = [
            {
                "name": _this.langService.transform("EnumField/category_351d2443_g9il/enumData/01", _this.lang, "专业技术"),
                "value": "01"
            },
            {
                "name": _this.langService.transform("EnumField/category_351d2443_g9il/enumData/02", _this.lang, "公司管理"),
                "value": "02"
            },
            {
                "name": _this.langService.transform("EnumField/category_351d2443_g9il/enumData/03", _this.lang, "销售人员"),
                "value": "03"
            },
            {
                "name": _this.langService.transform("EnumField/category_351d2443_g9il/enumData/04", _this.lang, "安全管理"),
                "value": "04"
            },
            {
                "name": _this.langService.transform("EnumField/category_351d2443_g9il/enumData/05", _this.lang, "研发人员"),
                "value": "05"
            }
        ];
        _this.category_351d2443_g9il_PlaceHolder = _this.langService.transform("EnumField/category_351d2443_g9il/placeHolder", _this.lang, "");
        _this.state_1d83bcc3_y84zEnumData = [
            {
                "name": _this.langService.transform("EnumField/state_1d83bcc3_y84z/enumData/zz", _this.lang, "在职"),
                "value": "zz"
            },
            {
                "name": _this.langService.transform("EnumField/state_1d83bcc3_y84z/enumData/tz", _this.lang, "停职"),
                "value": "tz"
            }
        ];
        _this.state_1d83bcc3_y84z_PlaceHolder = _this.langService.transform("EnumField/state_1d83bcc3_y84z/placeHolder", _this.lang, "");
        _this.code_830abdc2_xmf5_PlaceHolder = _this.langService.transform("TextBox/code_830abdc2_xmf5/placeHolder", _this.lang, "");
        _this.name_62f6f967_ljy5_PlaceHolder = _this.langService.transform("TextBox/name_62f6f967_ljy5/placeHolder", _this.lang, "");
        _this.countryOrArea_ae921ab7_77jq_PlaceHolder = _this.langService.transform("TextBox/countryOrArea_ae921ab7_77jq/placeHolder", _this.lang, "");
        _this.location_f268b1fe_gq8r_PlaceHolder = _this.langService.transform("TextBox/location_f268b1fe_gq8r/placeHolder", _this.lang, "");
        _this.postID_5b850216_8sgi_PlaceHolder = _this.langService.transform("TextBox/postID_5b850216_8sgi/placeHolder", _this.lang, "");
        _this.remark_794148b9_im8m_PlaceHolder = _this.langService.transform("TextBox/remark_794148b9_im8m/placeHolder", _this.lang, "");
        _this.telephone_PhoneNumber_d8210a21_g82b_PlaceHolder = _this.langService.transform("TextBox/telephone_PhoneNumber_d8210a21_g82b/placeHolder", _this.lang, "");
        _this.mailbox_Email_977b95f3_b1dh_PlaceHolder = _this.langService.transform("TextBox/mailbox_Email_977b95f3_b1dh/placeHolder", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusInvalidInput(verifyInformations, _this.rootElement);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    BasicFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.onFormLoad();
    };
    BasicFormComponent.prototype.ngAfterViewInit = function () {
        this.componentManagerService.appendControl('organization_Organization_ShortName_58a39191_yswj', this.organization_Organization_ShortName_58a39191_yswj);
    };
    BasicFormComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    BasicFormComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    BasicFormComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('organization_Organization_ShortName_58a39191_yswj'),
        tslib_1.__metadata("design:type", LookupGridComponent)
    ], BasicFormComponent.prototype, "organization_Organization_ShortName_58a39191_yswj", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], BasicFormComponent.prototype, "cls", void 0);
    BasicFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-basicformcomponent',
            templateUrl: './basicformcomponent.html',
            styleUrls: ['./basicformcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'basic-form-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: EmployeeRepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: BasicFormViewmodelForm },
                { provide: UIState, useClass: BasicFormViewmodelUIState },
                { provide: ViewModel, useClass: BasicFormViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            ComponentManagerService,
            DomSanitizer,
            Injector])
    ], BasicFormComponent);
    return BasicFormComponent;
}(FrameComponent));
export { BasicFormComponent };
