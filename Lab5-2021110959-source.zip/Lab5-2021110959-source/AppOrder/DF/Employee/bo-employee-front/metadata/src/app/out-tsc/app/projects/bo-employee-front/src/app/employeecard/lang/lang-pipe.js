import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/apporder/df/web/bo-employee-front/employeecard/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "TextBox/state_1d83bcc3_y84z/placeHolder": "", "TextBox/category_351d2443_g9il/placeHolder": "", "TextBox/secret_060fcd95_0t84/placeHolder": "", "telephone_d8210a21_7v7j": "联系电话", "TextBox/telephone_d8210a21_7v7j/placeHolder": "", "mailbox_977b95f3_agvf": "邮箱", "TextBox/mailbox_977b95f3_agvf/placeHolder": "", "organization_a6fddefe_p7e1": "组织", "TextBox/organization_a6fddefe_p7e1/placeHolder": "", "TextBox/organization_Organization_ShortName_58a39191_yswj/placeHolder": "", "displayName_7b98ca23_9d3u": "显示姓名", "TextBox/displayName_7b98ca23_9d3u/placeHolder": "", "secret_060fcd95_0t84": "密级", "EnumField/secret_060fcd95_0t84/placeHolder": "", "EnumField/secret_060fcd95_0t84/enumData/Public": "公开", "EnumField/secret_060fcd95_0t84/enumData/Internal": "一般", "EnumField/secret_060fcd95_0t84/enumData/Secret": "重要", "EnumField/secret_060fcd95_0t84/enumData/Confidential": "核心", "05c94199-7a80-4d91-a79b-5d84b66eb1d2": "个人信息", "FieldSet/05c94199-7a80-4d91-a79b-5d84b66eb1d2/collapseText": "", "FieldSet/05c94199-7a80-4d91-a79b-5d84b66eb1d2/expandText": "", "4176277c-b225-4990-b8da-fcf134b68aab": "工作信息", "FieldSet/4176277c-b225-4990-b8da-fcf134b68aab/collapseText": "", "FieldSet/4176277c-b225-4990-b8da-fcf134b68aab/expandText": "", "93ee6061-2b6d-4be0-929e-79c8c92a6044": "联系方式", "FieldSet/93ee6061-2b6d-4be0-929e-79c8c92a6044/collapseText": "", "FieldSet/93ee6061-2b6d-4be0-929e-79c8c92a6044/expandText": "", "GridField/certificateType_31c3af5f_0gxm/editor/certificateType_31c3af5f_h0rc": "文本", "GridField/certificateType_31c3af5f_0gxm/editor/TextBox/certificateType_31c3af5f_h0rc/placeHolder": "", "isMain_87169c85_dzqb": "是否主证件", "GridField/isMain_87169c85_dzqb/editor/isMain_87169c85_3skd": "复选框", "GridField/isMain_87169c85_dzqb/formatter/trueText": "是", "GridField/isMain_87169c85_dzqb/formatter/falseText": "否", "accountName_ed470fc7_rs80": "学校名称", "GridField/accountName_ed470fc7_rs80/editor/accountName_ed470fc7_g0jt": "学校名称", "GridField/accountName_ed470fc7_rs80/editor/TextBox/accountName_ed470fc7_g0jt/placeHolder": "", "accountNumber_161af061_q487": "入学时间", "GridField/accountNumber_161af061_q487/editor/accountNumber_161af061_zvyd": "入学时间", "GridField/accountNumber_161af061_q487/editor/TextBox/accountNumber_161af061_zvyd/placeHolder": "", "currency_9b94f059_pw92": "毕业时间", "GridField/currency_9b94f059_pw92/editor/currency_9b94f059_cnr2": "毕业时间", "GridField/currency_9b94f059_pw92/editor/TextBox/currency_9b94f059_cnr2/placeHolder": "", "accontBank_9223035c_04l1": "专业", "GridField/accontBank_9223035c_04l1/editor/accontBank_9223035c_6lg3": "专业", "GridField/accontBank_9223035c_04l1/editor/TextBox/accontBank_9223035c_6lg3/placeHolder": "", "province_2a8fd930_sjh8": "省份", "GridField/province_2a8fd930_sjh8/editor/province_2a8fd930_q1uo": "文本", "GridField/province_2a8fd930_sjh8/editor/TextBox/province_2a8fd930_q1uo/placeHolder": "", "city_065ad44f_pvox": "城市", "GridField/city_065ad44f_pvox/editor/city_065ad44f_r3dg": "文本", "GridField/city_065ad44f_pvox/editor/TextBox/city_065ad44f_r3dg/placeHolder": "", "state_8bc9863e_vyx8": "状态", "GridField/state_8bc9863e_vyx8/editor/state_8bc9863e_6wpu": "文本", "GridField/state_8bc9863e_vyx8/editor/TextBox/state_8bc9863e_6wpu/placeHolder": "", "certificateType_31c3af5f_0gxm": "岗位类型", "GridField/certificateType_31c3af5f_0gxm/enumData/JSG": "技术岗", "GridField/certificateType_31c3af5f_0gxm/enumData/GLG": "管理岗", "certificateCode_61a96c0a_eod4": "岗位编号", "GridField/certificateCode_61a96c0a_eod4/editor/certificateCode_61a96c0a_x2zb": "岗位编号", "GridField/certificateCode_61a96c0a_eod4/editor/TextBox/certificateCode_61a96c0a_x2zb/placeHolder": "", "position_8e560ff5_yl4e": "岗位", "GridField/position_8e560ff5_yl4e/enumData/YG": "员工", "GridField/position_8e560ff5_yl4e/enumData/JL": "经理", "salary_d48de21b_skol": "薪资", "GridField/salary_d48de21b_skol/editor/salary_d48de21b_mu8n": "薪资", "GridField/salary_d48de21b_skol/editor/NumberSpinner/salary_d48de21b_mu8n/placeHolder": "", "organization_8ec7a533_m5t5": "所属部门", "GridField/organization_8ec7a533_m5t5/editor/organization_8ec7a533_o2bs": "所属部门", "GridField/organization_8ec7a533_m5t5/editor/TextBox/organization_8ec7a533_o2bs/placeHolder": "", "company_c4dc5c51_2hrm": "所属公司", "GridField/company_c4dc5c51_2hrm/editor/company_c4dc5c51_ypg2": "所属公司", "GridField/company_c4dc5c51_2hrm/editor/TextBox/company_c4dc5c51_ypg2/placeHolder": "", "bankaccount-tab-page": "教育信息", "bankaccount-component-ref": "", "bankaccount-tab-toolbar": "", "bankaccountAddButton": "新增", "bankaccountRemoveButton": "删除", "certificatetype-tab-page": "工作信息", "certificatetype-component-ref": "", "certificatetype-tab-toolbar": "", "certificatetypeAddButton": "新增", "certificatetypeRemoveButton": "删除", "bankaccount-component": "", "bankaccount-component-layout": "", "dataGrid_bankaccount": "", "DataGrid/dataGrid_bankaccount/lineNumberTitle": "", "DataGrid/dataGrid_bankaccount/OperateEditButton": "编辑", "DataGrid/dataGrid_bankaccount/OperateDeleteButton": "删除", "DataGrid/dataGrid_bankaccount/OperateColumn": "操作", "schoolName_03445c2d_3qg6": "学校名称", "GridField/schoolName_03445c2d_3qg6/editor/schoolName_03445c2d_2ty0": "学校名称", "GridField/schoolName_03445c2d_3qg6/editor/TextBox/schoolName_03445c2d_2ty0/placeHolder": "", "timeInterval_f0c2cb3d_g4v5": "时间区间", "GridField/timeInterval_f0c2cb3d_g4v5/editor/timeInterval_f0c2cb3d_by5m": "时间区间", "GridField/timeInterval_f0c2cb3d_g4v5/editor/TextBox/timeInterval_f0c2cb3d_by5m/placeHolder": "", "studyType_afaddce9_x2tg": "学习形式", "GridField/studyType_afaddce9_x2tg/editor/studyType_afaddce9_owco": "学习形式", "GridField/studyType_afaddce9_x2tg/editor/TextBox/studyType_afaddce9_owco/placeHolder": "", "major_e7f1b580_px1p": "专业", "GridField/major_e7f1b580_px1p/editor/major_e7f1b580_z2rj": "专业", "GridField/major_e7f1b580_px1p/editor/TextBox/major_e7f1b580_z2rj/placeHolder": "", "education_a617eb0b_38et": "学历", "GridField/education_a617eb0b_38et/editor/education_a617eb0b_qwjt": "学历", "GridField/education_a617eb0b_38et/editor/TextBox/education_a617eb0b_qwjt/placeHolder": "", "eduSystem_3417c999_bh85": "学制", "GridField/eduSystem_3417c999_bh85/editor/eduSystem_3417c999_vxup": "学制", "GridField/eduSystem_3417c999_bh85/editor/TextBox/eduSystem_3417c999_vxup/placeHolder": "", "degree_553e6f70_563q": "学位", "GridField/degree_553e6f70_563q/editor/degree_553e6f70_jzte": "学位", "GridField/degree_553e6f70_563q/editor/TextBox/degree_553e6f70_jzte/placeHolder": "", "isFirstDegree_6e18be6a_s075": "是否第一学历", "GridField/isFirstDegree_6e18be6a_s075/editor/isFirstDegree_6e18be6a_w769": "是否第一学历", "GridField/isFirstDegree_6e18be6a_s075/formatter/trueText": "是", "GridField/isFirstDegree_6e18be6a_s075/formatter/falseText": "否", "isHighest_f326b212_aoqe": "是否最高学历", "GridField/isHighest_f326b212_aoqe/editor/isHighest_f326b212_4ykg": "是否最高学历", "GridField/isHighest_f326b212_aoqe/formatter/trueText": "是", "GridField/isHighest_f326b212_aoqe/formatter/falseText": "否", "certificatetype-component": "", "certificatetype-component-layout": "", "dataGrid_certificatetype": "", "DataGrid/dataGrid_certificatetype/lineNumberTitle": "", "DataGrid/dataGrid_certificatetype/OperateEditButton": "编辑", "DataGrid/dataGrid_certificatetype/OperateDeleteButton": "删除", "DataGrid/dataGrid_certificatetype/OperateColumn": "操作", "company_80d1344d_15gq": "工作单位", "GridField/company_80d1344d_15gq/editor/company_80d1344d_59dq": "工作单位", "GridField/company_80d1344d_15gq/editor/TextBox/company_80d1344d_59dq/placeHolder": "", "timeInterval_f4f4d93b_528r": "时间区间", "GridField/timeInterval_f4f4d93b_528r/editor/timeInterval_f4f4d93b_g4cd": "时间区间", "GridField/timeInterval_f4f4d93b_528r/editor/TextBox/timeInterval_f4f4d93b_g4cd/placeHolder": "", "position_b9e9c43c_hkl5": "岗位", "GridField/position_b9e9c43c_hkl5/editor/position_b9e9c43c_w5yb": "岗位", "GridField/position_b9e9c43c_hkl5/editor/TextBox/position_b9e9c43c_w5yb/placeHolder": "", "salary_e2da012a_wif8": "薪资", "GridField/salary_e2da012a_wif8/editor/salary_e2da012a_swou": "薪资", "GridField/salary_e2da012a_wif8/formatter/trueText": "是", "GridField/salary_e2da012a_wif8/formatter/falseText": "否", "certifier_04b1f958_ba8m": "证明人", "GridField/certifier_04b1f958_ba8m/editor/certifier_04b1f958_fk52": "证明人", "GridField/certifier_04b1f958_ba8m/editor/TextBox/certifier_04b1f958_fk52/placeHolder": "", "telephone_8210c899_gtbj": "证明人联系方式", "GridField/telephone_8210c899_gtbj/editor/telephone_8210c899_podi": "证明人联系方式", "GridField/telephone_8210c899_gtbj/editor/TextBox/telephone_8210c899_podi/placeHolder": "", "detail-container": "", "detail-section": "", "Section/detail-section/mainTitle": "", "Section/detail-section/subTitle": "", "detail-tab": "", "eduinfo-tab-page": "教育信息", "eduinfo-component-ref": "", "eduinfo-tab-toolbar": "", "eduinfoAddButton": "新增", "eduinfoRemoveButton": "删除", "jobinfo-tab-page": "工作信息", "jobinfo-component-ref": "", "jobinfo-tab-toolbar": "", "jobinfoAddButton": "新增", "jobinfoRemoveButton": "删除", "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "main-container": "", "like-card-container": "", "basic-form-component-ref": "", "container_8958": "", "section_8958": "", "Section/section_8958/mainTitle": "主标题", "Section/section_8958/subTitle": "", "tab_8958": "", "tabpage_8958": "教育信息", "eduinfo-5n7m-component-ref": "", "tab_toolbar_8958": "", "TabToolbar-cloned-rind": "新增", "tab-toolbaritem-2814": "删除", "tabpage_4103": "工作信息", "jobinfo-vynn-component-ref": "", "tab_toolbar_4103": "", "tab_toolbaritem_4103": "新增", "TabToolbar-cloned-1wik": "删除", "basic-form-component": "", "basic-form-section": "", "Section/basic-form-section/mainTitle": "基本信息", "Section/basic-form-section/subTitle": "", "basic-form-layout": "", "755dc17e-8c67-4d5c-b0f9-7a02001496d0": "个人信息", "FieldSet/755dc17e-8c67-4d5c-b0f9-7a02001496d0/collapseText": "", "FieldSet/755dc17e-8c67-4d5c-b0f9-7a02001496d0/expandText": "", "code_830abdc2_xmf5": "编号", "TextBox/code_830abdc2_xmf5/placeHolder": "", "name_62f6f967_ljy5": "名称", "TextBox/name_62f6f967_ljy5/placeHolder": "", "gender_58ff12cc_9oof": "性别", "EnumField/gender_58ff12cc_9oof/placeHolder": "", "EnumField/gender_58ff12cc_9oof/enumData/men": "男", "EnumField/gender_58ff12cc_9oof/enumData/women": "女", "cc3a1b0c-463e-4021-bdea-d19d10d55d5c": "工作信息", "FieldSet/cc3a1b0c-463e-4021-bdea-d19d10d55d5c/collapseText": "", "FieldSet/cc3a1b0c-463e-4021-bdea-d19d10d55d5c/expandText": "", "organization_Organization_ShortName_58a39191_yswj": "组织", "LookupEdit/organization_Organization_ShortName_58a39191_yswj/placeHolder": "", "LookupEdit/organization_Organization_ShortName_58a39191_yswj/dialogTitle": "", "countryOrArea_ae921ab7_77jq": "所属国家或地区", "TextBox/countryOrArea_ae921ab7_77jq/placeHolder": "", "location_f268b1fe_gq8r": "常驻地", "TextBox/location_f268b1fe_gq8r/placeHolder": "", "category_351d2443_g9il": "人员类别", "EnumField/category_351d2443_g9il/placeHolder": "", "EnumField/category_351d2443_g9il/enumData/01": "专业技术", "EnumField/category_351d2443_g9il/enumData/02": "公司管理", "EnumField/category_351d2443_g9il/enumData/03": "销售人员", "EnumField/category_351d2443_g9il/enumData/04": "安全管理", "EnumField/category_351d2443_g9il/enumData/05": "研发人员", "postID_5b850216_8sgi": "职级", "TextBox/postID_5b850216_8sgi/placeHolder": "", "state_1d83bcc3_y84z": "状态", "EnumField/state_1d83bcc3_y84z/placeHolder": "", "EnumField/state_1d83bcc3_y84z/enumData/zz": "在职", "EnumField/state_1d83bcc3_y84z/enumData/tz": "停职", "remark_794148b9_im8m": "备注", "TextBox/remark_794148b9_im8m/placeHolder": "", "5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7": "联系方式", "FieldSet/5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7/collapseText": "", "FieldSet/5eee9be8-c42d-46a0-a8f5-0fab2a62b8a7/expandText": "", "telephone_PhoneNumber_d8210a21_g82b": "联系电话", "TextBox/telephone_PhoneNumber_d8210a21_g82b/placeHolder": "", "mailbox_Email_977b95f3_b1dh": "邮箱", "TextBox/mailbox_Email_977b95f3_b1dh/placeHolder": "", "eduinfo-5n7m-component": "", "eduinfo-5n7m-component-layout": "", "eduinfo-5n7m-dataGrid": "", "DataGrid/eduinfo-5n7m-dataGrid/lineNumberTitle": "", "DataGrid/eduinfo-5n7m-dataGrid/OperateEditButton": "编辑", "DataGrid/eduinfo-5n7m-dataGrid/OperateDeleteButton": "删除", "DataGrid/eduinfo-5n7m-dataGrid/OperateColumn": "操作", "schoolName_03445c2d_x1dt": "学校名称", "GridField/schoolName_03445c2d_x1dt/editor/schoolName_03445c2d_nufh": "学校名称", "GridField/schoolName_03445c2d_x1dt/editor/TextBox/schoolName_03445c2d_nufh/placeHolder": "", "timeInterval_f0c2cb3d_oajz": "时间区间", "GridField/timeInterval_f0c2cb3d_oajz/editor/timeInterval_f0c2cb3d_waop": "时间区间", "GridField/timeInterval_f0c2cb3d_oajz/editor/TextBox/timeInterval_f0c2cb3d_waop/placeHolder": "", "studyType_afaddce9_ov6q": "学习形式", "GridField/studyType_afaddce9_ov6q/editor/studyType_afaddce9_5ozc": "学习形式", "GridField/studyType_afaddce9_ov6q/editor/TextBox/studyType_afaddce9_5ozc/placeHolder": "", "education_a617eb0b_1ggh": "学历", "GridField/education_a617eb0b_1ggh/editor/education_a617eb0b_qwl1": "学历", "GridField/education_a617eb0b_1ggh/editor/TextBox/education_a617eb0b_qwl1/placeHolder": "", "major_e7f1b580_qr7r": "专业", "GridField/major_e7f1b580_qr7r/editor/major_e7f1b580_lv8a": "专业", "GridField/major_e7f1b580_qr7r/editor/TextBox/major_e7f1b580_lv8a/placeHolder": "", "eduSystem_3417c999_2vup": "学制", "GridField/eduSystem_3417c999_2vup/editor/eduSystem_3417c999_yw5h": "学制", "GridField/eduSystem_3417c999_2vup/editor/TextBox/eduSystem_3417c999_yw5h/placeHolder": "", "degree_553e6f70_81mn": "学位", "GridField/degree_553e6f70_81mn/editor/degree_553e6f70_ffvk": "学位", "GridField/degree_553e6f70_81mn/editor/TextBox/degree_553e6f70_ffvk/placeHolder": "", "isFirstDegree_6e18be6a_uqsh": "是否第一学历", "GridField/isFirstDegree_6e18be6a_uqsh/editor/isFirstDegree_6e18be6a_rpvu": "是否第一学历", "GridField/isFirstDegree_6e18be6a_uqsh/formatter/trueText": "是", "GridField/isFirstDegree_6e18be6a_uqsh/formatter/falseText": "否", "isHighest_f326b212_0hiz": "是否最高学历", "GridField/isHighest_f326b212_0hiz/editor/isHighest_f326b212_olqq": "是否最高学历", "GridField/isHighest_f326b212_0hiz/formatter/trueText": "是", "GridField/isHighest_f326b212_0hiz/formatter/falseText": "否", "jobinfo-vynn-component": "", "jobinfo-vynn-component-layout": "", "jobinfo-vynn-dataGrid": "", "DataGrid/jobinfo-vynn-dataGrid/lineNumberTitle": "", "DataGrid/jobinfo-vynn-dataGrid/OperateEditButton": "编辑", "DataGrid/jobinfo-vynn-dataGrid/OperateDeleteButton": "删除", "DataGrid/jobinfo-vynn-dataGrid/OperateColumn": "操作", "company_80d1344d_cba8": "工作单位", "GridField/company_80d1344d_cba8/editor/company_80d1344d_q68s": "工作单位", "GridField/company_80d1344d_cba8/editor/TextBox/company_80d1344d_q68s/placeHolder": "", "timeInterval_f4f4d93b_4zx8": "时间区间", "GridField/timeInterval_f4f4d93b_4zx8/editor/timeInterval_f4f4d93b_oa46": "时间区间", "GridField/timeInterval_f4f4d93b_4zx8/editor/TextBox/timeInterval_f4f4d93b_oa46/placeHolder": "", "position_b9e9c43c_wepj": "岗位", "GridField/position_b9e9c43c_wepj/editor/position_b9e9c43c_527o": "岗位", "GridField/position_b9e9c43c_wepj/editor/TextBox/position_b9e9c43c_527o/placeHolder": "", "salary_e2da012a_z3rc": "薪资", "GridField/salary_e2da012a_z3rc/editor/salary_e2da012a_c0id": "薪资", "GridField/salary_e2da012a_z3rc/formatter/trueText": "是", "GridField/salary_e2da012a_z3rc/formatter/falseText": "否", "certifier_04b1f958_8yzf": "证明人", "GridField/certifier_04b1f958_8yzf/editor/certifier_04b1f958_jipj": "证明人", "GridField/certifier_04b1f958_8yzf/editor/TextBox/certifier_04b1f958_jipj/placeHolder": "", "telephone_8210c899_nr8c": "证明人联系方式", "GridField/telephone_8210c899_nr8c/editor/telephone_8210c899_psm2": "证明人联系方式", "GridField/telephone_8210c899_nr8c/editor/TextBox/telephone_8210c899_psm2/placeHolder": "" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/apporder/df/web/bo-employee-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "employeecard/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
