import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var JobinfoVynnComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(JobinfoVynnComponentViewmodelForm, _super);
    function JobinfoVynnComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'company',
            name: "{{company_80d1344d_cba8}}",
            binding: 'company',
            updateOn: 'blur',
            defaultI18nValue: '工作单位',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "company", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'timeInterval',
            name: "{{timeInterval_f4f4d93b_4zx8}}",
            binding: 'timeInterval',
            updateOn: 'blur',
            defaultI18nValue: '时间区间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "timeInterval", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'position',
            name: "{{position_b9e9c43c_wepj}}",
            binding: 'position',
            updateOn: 'blur',
            defaultI18nValue: '岗位',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "position", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'salary',
            name: "{{salary_e2da012a_z3rc}}",
            binding: 'salary',
            updateOn: 'change',
            defaultI18nValue: '薪资',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "salary", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'certifier',
            name: "{{certifier_04b1f958_8yzf}}",
            binding: 'certifier',
            updateOn: 'blur',
            defaultI18nValue: '证明人',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "certifier", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'telephone',
            name: "{{telephone_8210c899_nr8c}}",
            binding: 'telephone',
            updateOn: 'blur',
            defaultI18nValue: '证明人联系方式',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JobinfoVynnComponentViewmodelForm.prototype, "telephone", void 0);
    JobinfoVynnComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '工作信息',
            enableValidate: true
        }),
        Injectable()
    ], JobinfoVynnComponentViewmodelForm);
    return JobinfoVynnComponentViewmodelForm;
}(Form));
export { JobinfoVynnComponentViewmodelForm };
