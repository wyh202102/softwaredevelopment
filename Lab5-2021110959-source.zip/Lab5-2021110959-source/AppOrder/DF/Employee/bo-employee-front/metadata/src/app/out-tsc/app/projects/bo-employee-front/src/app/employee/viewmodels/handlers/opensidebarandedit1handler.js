import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SidebarService as SidebarService1 } from '@farris/command-services';
import { CardDataService as CardDataService1 } from '@farris/command-services';
import { StateMachineService as StateMachineService1 } from '@farris/command-services';
var OpenSidebarAndEdit1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(OpenSidebarAndEdit1Handler, _super);
    function OpenSidebarAndEdit1Handler(_SidebarService1, _CardDataService1, _StateMachineService1) {
        var _this = _super.call(this) || this;
        _this._SidebarService1 = _SidebarService1;
        _this._CardDataService1 = _CardDataService1;
        _this._StateMachineService1 = _StateMachineService1;
        return _this;
    }
    OpenSidebarAndEdit1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('openSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'openSidebar', args, context);
        });
        this.addTask('update', function (context) {
            var args = [];
            return _this.invoke(_this._CardDataService1, 'update', args, context);
        });
        this.addTask('transit', function (context) {
            var args = [
                '{COMMAND~/params/transitionAction}'
            ];
            return _this.invoke(_this._StateMachineService1, 'transit', args, context);
        });
        this.addLink('openSidebar', 'update', "1==1");
        this.addLink('update', 'transit', "1==1");
    };
    OpenSidebarAndEdit1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'OpenSidebarAndEdit1'
        }),
        tslib_1.__metadata("design:paramtypes", [SidebarService1,
            CardDataService1,
            StateMachineService1])
    ], OpenSidebarAndEdit1Handler);
    return OpenSidebarAndEdit1Handler;
}(CommandHandler));
export { OpenSidebarAndEdit1Handler };
