import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { PhoneNumber1ea2Entity } from './phonenumber1ea2entity';
import { EmailD542Entity } from './emaild542entity';
var EmployeeEntity = /** @class */ (function (_super) {
    tslib_1.__extends(EmployeeEntity, _super);
    function EmployeeEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Remark',
            dataField: 'remark',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Remark',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1000],
                    message: '最大长度为1000',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'State',
            dataField: 'state',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'zz',
            path: 'State',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "state", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Gender',
            dataField: 'gender',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'men',
            path: 'Gender',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "gender", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Category',
            dataField: 'category',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '01',
            path: 'Category',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "category", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'telephone',
            originalDataField: 'Telephone',
            type: PhoneNumber1ea2Entity
        }),
        tslib_1.__metadata("design:type", PhoneNumber1ea2Entity)
    ], EmployeeEntity.prototype, "telephone", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'mailbox',
            originalDataField: 'Mailbox',
            type: EmailD542Entity
        }),
        tslib_1.__metadata("design:type", EmailD542Entity)
    ], EmployeeEntity.prototype, "mailbox", void 0);
    EmployeeEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Employee",
            nodeCode: "employees",
            allowEmpty: true
        })
    ], EmployeeEntity);
    return EmployeeEntity;
}(Entity));
export { EmployeeEntity };
