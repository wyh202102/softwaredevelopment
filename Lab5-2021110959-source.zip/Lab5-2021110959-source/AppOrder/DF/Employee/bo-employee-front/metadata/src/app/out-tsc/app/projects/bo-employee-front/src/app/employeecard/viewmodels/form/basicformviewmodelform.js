import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'code_830abdc2_xmf5',
            name: "{{code_830abdc2_xmf5}}",
            binding: 'code',
            updateOn: 'blur',
            defaultI18nValue: '编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "code", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_62f6f967_ljy5',
            name: "{{name_62f6f967_ljy5}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'remark_794148b9_im8m',
            name: "{{remark_794148b9_im8m}}",
            binding: 'remark',
            updateOn: 'blur',
            defaultI18nValue: '备注',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'state_1d83bcc3_y84z',
            name: "{{state_1d83bcc3_y84z}}",
            binding: 'state',
            updateOn: 'blur',
            defaultI18nValue: '状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "state", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'gender_58ff12cc_9oof',
            name: "{{gender_58ff12cc_9oof}}",
            binding: 'gender',
            updateOn: 'change',
            defaultI18nValue: '性别',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "gender", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'countryOrArea_ae921ab7_77jq',
            name: "{{countryOrArea_ae921ab7_77jq}}",
            binding: 'countryOrArea',
            updateOn: 'blur',
            defaultI18nValue: '所属国家或地区',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "countryOrArea", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'location_f268b1fe_gq8r',
            name: "{{location_f268b1fe_gq8r}}",
            binding: 'location',
            updateOn: 'blur',
            defaultI18nValue: '常驻地',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "location", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'postID_5b850216_8sgi',
            name: "{{postID_5b850216_8sgi}}",
            binding: 'postID',
            updateOn: 'blur',
            defaultI18nValue: '职级',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "postID", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'category_351d2443_g9il',
            name: "{{category_351d2443_g9il}}",
            binding: 'category',
            updateOn: 'blur',
            defaultI18nValue: '人员类别',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "category", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'telephone_PhoneNumber_d8210a21_g82b',
            name: "{{telephone_PhoneNumber_d8210a21_g82b}}",
            binding: 'telephone.phoneNumber',
            updateOn: 'blur',
            defaultI18nValue: '联系电话',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "telephone_PhoneNumber", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'mailbox_Email_977b95f3_b1dh',
            name: "{{mailbox_Email_977b95f3_b1dh}}",
            binding: 'mailbox.email',
            updateOn: 'blur',
            defaultI18nValue: '邮箱',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "mailbox_Email", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'organization_Organization_ShortName_58a39191_yswj',
            name: "{{organization_Organization_ShortName_58a39191_yswj}}",
            binding: 'organization.organization_Name',
            updateOn: 'blur',
            defaultI18nValue: '组织',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "organization_Organization_Name", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '行政人员',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
