import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SidebarService as SidebarService1 } from '@farris/command-services';
import { ValidationService as ValidationService1 } from '@farris/command-services';
import { ListDataService as ListDataService1 } from '@farris/command-services';
import { CardDataService as CardDataService1 } from '@farris/command-services';
import { StateMachineService as StateMachineService1 } from '@farris/command-services';
var CheckBeforeClosingSidebar1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(CheckBeforeClosingSidebar1Handler, _super);
    function CheckBeforeClosingSidebar1Handler(_SidebarService1, _ValidationService1, _ListDataService1, _CardDataService1, _StateMachineService1) {
        var _this = _super.call(this) || this;
        _this._SidebarService1 = _SidebarService1;
        _this._ValidationService1 = _ValidationService1;
        _this._ListDataService1 = _ListDataService1;
        _this._CardDataService1 = _CardDataService1;
        _this._StateMachineService1 = _StateMachineService1;
        return _this;
    }
    CheckBeforeClosingSidebar1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('confirmBeforeClosingSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'confirmBeforeClosingSidebar', args, context);
        });
        this.addTask('cancelWithoutCheck', function (context) {
            var args = [];
            return _this.invoke(_this._CardDataService1, 'cancelWithoutCheck', args, context);
        });
        this.addTask('load', function (context) {
            var args = [
                '',
                ''
            ];
            return _this.invoke(_this._ListDataService1, 'load', args, context);
        });
        this.addTask('updateWithoutEmpty', function (context) {
            var args = [];
            return _this.invoke(_this._CardDataService1, 'updateWithoutEmpty', args, context);
        });
        this.addTask('transit', function (context) {
            var args = [
                '{COMMAND~/params/transitionAction}'
            ];
            return _this.invoke(_this._StateMachineService1, 'transit', args, context);
        });
        this.addTask('resetValidation', function (context) {
            var args = [];
            return _this.invoke(_this._ValidationService1, 'resetValidation', args, context);
        });
        this.addTask('continueClosingSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'continueClosingSidebar', args, context);
        });
        this.addTask('stopClosingSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'stopClosingSidebar', args, context);
        });
        this.addLink('confirmBeforeClosingSidebar', 'cancelWithoutCheck', "'{COMMAND~/results/confirmBeforeClosingSidebar}'==='true'");
        this.addLink('confirmBeforeClosingSidebar', 'stopClosingSidebar', "'{COMMAND~/results/confirmBeforeClosingSidebar}'==='false'");
        this.addLink('cancelWithoutCheck', 'load', "1==1");
        this.addLink('load', 'updateWithoutEmpty', "1==1");
        this.addLink('updateWithoutEmpty', 'transit', "1==1");
        this.addLink('transit', 'resetValidation', "1==1");
        this.addLink('resetValidation', 'continueClosingSidebar', "1==1");
    };
    CheckBeforeClosingSidebar1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'CheckBeforeClosingSidebar1'
        }),
        tslib_1.__metadata("design:paramtypes", [SidebarService1,
            ValidationService1,
            ListDataService1,
            CardDataService1,
            StateMachineService1])
    ], CheckBeforeClosingSidebar1Handler);
    return CheckBeforeClosingSidebar1Handler;
}(CommandHandler));
export { CheckBeforeClosingSidebar1Handler };
