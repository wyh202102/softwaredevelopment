import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/apporder/df/web/bo-employee-front/employee/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "title": "行政人员", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-view": "查看", "button-delete": "删除", "page-main": "", "data-grid-component-ref": "", "detail-form-sidebar": "", "button-sidebar-add": "新增", "button-sidebar-edit": "编辑", "detail-component-ref": "", "data-grid-component": "", "data-grid-section": "", "Section/data-grid-section/mainTitle": "", "Section/data-grid-section/subTitle": "", "dataGrid": "", "DataGrid/dataGrid/lineNumberTitle": "", "DataGrid/dataGrid/OperateEditButton": "编辑", "DataGrid/dataGrid/OperateDeleteButton": "删除", "DataGrid/dataGrid/OperateColumn": "操作", "name_f613d27e_js7n": "姓名", "gender_847aaa49_0ivn": "性别", "GridField/gender_847aaa49_0ivn/enumData/men": "男", "GridField/gender_847aaa49_0ivn/enumData/women": "女", "category_e457e7cc_fxel": "人员类别", "GridField/category_e457e7cc_fxel/enumData/01": "系统管理员", "GridField/category_e457e7cc_fxel/enumData/02": "销售人员", "GridField/category_e457e7cc_fxel/enumData/03": "采购人员", "GridField/category_e457e7cc_fxel/enumData/04": "安全管理", "state_90a44a8c_clck": "状态", "GridField/state_90a44a8c_clck/enumData/zz": "在职", "GridField/state_90a44a8c_clck/enumData/tz": "停职", "detail-form-component": "", "detail-form-layout": "", "name_f613d27e_ijgf": "姓名", "TextBox/name_f613d27e_ijgf/placeHolder": "", "gender_847aaa49_zmwy": "性别", "EnumField/gender_847aaa49_zmwy/placeHolder": "", "EnumField/gender_847aaa49_zmwy/enumData/men": "男", "EnumField/gender_847aaa49_zmwy/enumData/women": "女", "category_e457e7cc_z0p3": "人员类别", "EnumField/category_e457e7cc_z0p3/placeHolder": "", "EnumField/category_e457e7cc_z0p3/enumData/01": "系统管理员", "EnumField/category_e457e7cc_z0p3/enumData/02": "销售人员", "EnumField/category_e457e7cc_z0p3/enumData/03": "采购人员", "EnumField/category_e457e7cc_z0p3/enumData/04": "安全管理", "state_90a44a8c_nlqa": "状态", "EnumField/state_90a44a8c_nlqa/placeHolder": "", "EnumField/state_90a44a8c_nlqa/enumData/zz": "在职", "EnumField/state_90a44a8c_nlqa/enumData/tz": "停职", "telephone_PhoneNumber_1ea2cd47_7cno": "手机电话号码", "TextBox/telephone_PhoneNumber_1ea2cd47_7cno/placeHolder": "", "mailbox_Email_d5421d62_evhf": "邮箱", "TextBox/mailbox_Email_d5421d62_evhf/placeHolder": "", "remark_2081e24b_f595": "备注", "TextBox/remark_2081e24b_f595/placeHolder": "" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/apporder/df/web/bo-employee-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "employee/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
