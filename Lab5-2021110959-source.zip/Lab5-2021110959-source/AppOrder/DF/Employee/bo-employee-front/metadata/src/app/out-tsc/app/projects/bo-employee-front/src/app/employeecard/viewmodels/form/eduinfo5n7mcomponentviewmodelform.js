import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var Eduinfo5n7mComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(Eduinfo5n7mComponentViewmodelForm, _super);
    function Eduinfo5n7mComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'schoolName',
            name: "{{schoolName_03445c2d_x1dt}}",
            binding: 'schoolName',
            updateOn: 'blur',
            defaultI18nValue: '学校名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "schoolName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'timeInterval',
            name: "{{timeInterval_f0c2cb3d_oajz}}",
            binding: 'timeInterval',
            updateOn: 'blur',
            defaultI18nValue: '时间区间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "timeInterval", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'studyType',
            name: "{{studyType_afaddce9_ov6q}}",
            binding: 'studyType',
            updateOn: 'blur',
            defaultI18nValue: '学习形式',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "studyType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'education',
            name: "{{education_a617eb0b_1ggh}}",
            binding: 'education',
            updateOn: 'blur',
            defaultI18nValue: '学历',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "education", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'major',
            name: "{{major_e7f1b580_qr7r}}",
            binding: 'major',
            updateOn: 'blur',
            defaultI18nValue: '专业',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "major", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'eduSystem',
            name: "{{eduSystem_3417c999_2vup}}",
            binding: 'eduSystem',
            updateOn: 'blur',
            defaultI18nValue: '学制',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "eduSystem", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'degree',
            name: "{{degree_553e6f70_81mn}}",
            binding: 'degree',
            updateOn: 'blur',
            defaultI18nValue: '学位',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "degree", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'isFirstDegree',
            name: "{{isFirstDegree_6e18be6a_uqsh}}",
            binding: 'isFirstDegree',
            updateOn: 'change',
            defaultI18nValue: '是否第一学历',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "isFirstDegree", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'isHighest',
            name: "{{isHighest_f326b212_0hiz}}",
            binding: 'isHighest',
            updateOn: 'change',
            defaultI18nValue: '是否最高学历',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], Eduinfo5n7mComponentViewmodelForm.prototype, "isHighest", void 0);
    Eduinfo5n7mComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '教育信息',
            enableValidate: true
        }),
        Injectable()
    ], Eduinfo5n7mComponentViewmodelForm);
    return Eduinfo5n7mComponentViewmodelForm;
}(Form));
export { Eduinfo5n7mComponentViewmodelForm };
