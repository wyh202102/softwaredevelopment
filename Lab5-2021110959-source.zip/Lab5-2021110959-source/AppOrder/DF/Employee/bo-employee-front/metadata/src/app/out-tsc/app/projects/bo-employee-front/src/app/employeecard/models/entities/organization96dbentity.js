import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var Organization96dbEntity = /** @class */ (function (_super) {
    tslib_1.__extends(Organization96dbEntity, _super);
    function Organization96dbEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Organization',
            dataField: 'organization',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Organization.Organization',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], Organization96dbEntity.prototype, "organization", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'organization_Code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Organization.Organization_Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], Organization96dbEntity.prototype, "organization_Code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'organization_Name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Organization.Organization_Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], Organization96dbEntity.prototype, "organization_Name", void 0);
    Organization96dbEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Organization",
            nodeCode: "organization"
        })
    ], Organization96dbEntity);
    return Organization96dbEntity;
}(Entity));
export { Organization96dbEntity };
