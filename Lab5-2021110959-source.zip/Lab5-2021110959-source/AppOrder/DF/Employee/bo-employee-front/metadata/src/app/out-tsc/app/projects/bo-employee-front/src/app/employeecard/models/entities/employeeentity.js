import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, EntityList, NgList, NgEntity } from '@farris/devkit';
import { EduInfoEntity } from './eduinfoentity';
import { JobInfoEntity } from './jobinfoentity';
import { Organization96dbEntity } from './organization96dbentity';
import { PhoneNumberD821Entity } from './phonenumberd821entity';
import { Email977bEntity } from './email977bentity';
var EmployeeEntity = /** @class */ (function (_super) {
    tslib_1.__extends(EmployeeEntity, _super);
    function EmployeeEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1000],
                    message: '最大长度为1000',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1000],
                    message: '最大长度为1000',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Remark',
            dataField: 'remark',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Remark',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [1000],
                    message: '最大长度为1000',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'State',
            dataField: 'state',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'zz',
            path: 'State',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "state", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Gender',
            dataField: 'gender',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'men',
            path: 'Gender',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "gender", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'CountryOrArea',
            dataField: 'countryOrArea',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'CountryOrArea',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [22],
                    message: '最大长度为22',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "countryOrArea", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Location',
            dataField: 'location',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Location',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [22],
                    message: '最大长度为22',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "location", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'PostID',
            dataField: 'postID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'PostID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "postID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Category',
            dataField: 'category',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: '01',
            path: 'Category',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "category", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'DisplayName',
            dataField: 'displayName',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'DisplayName',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmployeeEntity.prototype, "displayName", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Secret',
            dataField: 'secret',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Public',
            path: 'Secret',
        }),
        tslib_1.__metadata("design:type", Object)
    ], EmployeeEntity.prototype, "secret", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'eduInfos',
            originalDataField: '',
            type: EduInfoEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], EmployeeEntity.prototype, "eduInfos", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'jobInfos',
            originalDataField: '',
            type: JobInfoEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], EmployeeEntity.prototype, "jobInfos", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'organization',
            originalDataField: 'Organization',
            type: Organization96dbEntity
        }),
        tslib_1.__metadata("design:type", Organization96dbEntity)
    ], EmployeeEntity.prototype, "organization", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'telephone',
            originalDataField: 'Telephone',
            type: PhoneNumberD821Entity
        }),
        tslib_1.__metadata("design:type", PhoneNumberD821Entity)
    ], EmployeeEntity.prototype, "telephone", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'mailbox',
            originalDataField: 'Mailbox',
            type: Email977bEntity
        }),
        tslib_1.__metadata("design:type", Email977bEntity)
    ], EmployeeEntity.prototype, "mailbox", void 0);
    EmployeeEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Employee",
            nodeCode: "employees"
        })
    ], EmployeeEntity);
    return EmployeeEntity;
}(Entity));
export { EmployeeEntity };
