import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { CommandHandler, NgCommandHandler } from '@farris/devkit';
import { SidebarService as SidebarService1 } from '@farris/command-services';
import { ListDataService as ListDataService1 } from '@farris/command-services';
import { StateMachineService as StateMachineService1 } from '@farris/command-services';
var OpenSidebarAndAdd1Handler = /** @class */ (function (_super) {
    tslib_1.__extends(OpenSidebarAndAdd1Handler, _super);
    function OpenSidebarAndAdd1Handler(_SidebarService1, _ListDataService1, _StateMachineService1) {
        var _this = _super.call(this) || this;
        _this._SidebarService1 = _SidebarService1;
        _this._ListDataService1 = _ListDataService1;
        _this._StateMachineService1 = _StateMachineService1;
        return _this;
    }
    OpenSidebarAndAdd1Handler.prototype.schedule = function () {
        var _this = this;
        this.addTask('openSidebar', function (context) {
            var args = [];
            return _this.invoke(_this._SidebarService1, 'openSidebar', args, context);
        });
        this.addTask('append', function (context) {
            var args = [];
            return _this.invoke(_this._ListDataService1, 'append', args, context);
        });
        this.addTask('transit', function (context) {
            var args = [
                '{COMMAND~/params/transitionAction}'
            ];
            return _this.invoke(_this._StateMachineService1, 'transit', args, context);
        });
        this.addLink('openSidebar', 'append', "1==1");
        this.addLink('append', 'transit', "1==1");
    };
    OpenSidebarAndAdd1Handler = tslib_1.__decorate([
        Injectable(),
        NgCommandHandler({
            commandName: 'OpenSidebarAndAdd1'
        }),
        tslib_1.__metadata("design:paramtypes", [SidebarService1,
            ListDataService1,
            StateMachineService1])
    ], OpenSidebarAndAdd1Handler);
    return OpenSidebarAndAdd1Handler;
}(CommandHandler));
export { OpenSidebarAndAdd1Handler };
