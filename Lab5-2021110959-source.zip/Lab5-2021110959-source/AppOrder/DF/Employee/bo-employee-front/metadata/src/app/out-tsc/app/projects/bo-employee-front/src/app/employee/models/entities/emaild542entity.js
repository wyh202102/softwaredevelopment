import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var EmailD542Entity = /** @class */ (function (_super) {
    tslib_1.__extends(EmailD542Entity, _super);
    function EmailD542Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Email',
            dataField: 'email',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Mailbox.Email',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [500],
                    message: '最大长度为500',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], EmailD542Entity.prototype, "email", void 0);
    EmailD542Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Mailbox",
            nodeCode: "mailbox"
        })
    ], EmailD542Entity);
    return EmailD542Entity;
}(Entity));
export { EmailD542Entity };
