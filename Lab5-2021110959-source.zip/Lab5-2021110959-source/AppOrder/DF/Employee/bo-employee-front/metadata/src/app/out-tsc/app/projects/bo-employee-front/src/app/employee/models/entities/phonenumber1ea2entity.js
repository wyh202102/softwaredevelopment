import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var PhoneNumber1ea2Entity = /** @class */ (function (_super) {
    tslib_1.__extends(PhoneNumber1ea2Entity, _super);
    function PhoneNumber1ea2Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'PhoneNumber',
            dataField: 'phoneNumber',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Telephone.PhoneNumber',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PhoneNumber1ea2Entity.prototype, "phoneNumber", void 0);
    PhoneNumber1ea2Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "Telephone",
            nodeCode: "telephone"
        })
    ], PhoneNumber1ea2Entity);
    return PhoneNumber1ea2Entity;
}(Entity));
export { PhoneNumber1ea2Entity };
