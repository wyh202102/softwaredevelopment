import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ViewModel } from '@farris/devkit';
var DetailFormComponentViewmodel = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodel, _super);
    function DetailFormComponentViewmodel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bindingPath = '/';
        _this.dom = {};
        return _this;
    }
    DetailFormComponentViewmodel = tslib_1.__decorate([
        Injectable()
    ], DetailFormComponentViewmodel);
    return DetailFormComponentViewmodel;
}(ViewModel));
export { DetailFormComponentViewmodel };
