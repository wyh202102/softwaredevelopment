package com.inspur.gs.apporder.df.merchant.merchant.back.merchant.common;
import com.inspur.edp.cef.entity.entity.EntityDataUtils;
import com.inspur.edp.cef.entity.entity.IEntityData;
import java.util.Date;

public final class MerchantUtils{
    public static String getID(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"ID");
    }
    public static void setID(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"ID",propertyValue);
    }
    public static Date getVersion(IEntityData data){
        return (Date)EntityDataUtils.getValue(data,"Version");
    }
    public static void setVersion(IEntityData data,Date propertyValue){
        EntityDataUtils.setValue(data,"Version",propertyValue);
    }
    public static String getMerchantName(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"MerchantName");
    }
    public static void setMerchantName(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"MerchantName",propertyValue);
    }
    public static String getMerchantType(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"MerchantType");
    }
    public static void setMerchantType(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"MerchantType",propertyValue);
    }
    public static String getEmail(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"Email");
    }
    public static void setEmail(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"Email",propertyValue);
    }
    public static String getTelephone(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"Telephone");
    }
    public static void setTelephone(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"Telephone",propertyValue);
    }
    public static String getRemark(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"Remark");
    }
    public static void setRemark(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"Remark",propertyValue);
    }
    public static String getName(IEntityData data){
        return (String)EntityDataUtils.getValue(data,"Name");
    }
    public static void setName(IEntityData data,String propertyValue){
        EntityDataUtils.setValue(data,"Name",propertyValue);
    }
}