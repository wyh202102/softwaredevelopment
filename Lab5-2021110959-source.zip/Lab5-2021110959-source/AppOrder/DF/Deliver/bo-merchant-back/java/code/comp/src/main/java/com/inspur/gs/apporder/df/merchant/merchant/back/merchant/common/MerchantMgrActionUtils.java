package com.inspur.gs.apporder.df.merchant.merchant.back.merchant.common;
import com.inspur.edp.bef.api.BefRtBeanUtil;;
import com.inspur.edp.bef.api.be.MgrActionUtils;
import com.inspur.edp.bef.api.lcp.IStandardLcp;;

public final class MerchantMgrActionUtils{
    public static com.inspur.edp.cef.entity.entity.IEntityData PathHierarchyCreateSibling(java.lang.String dataID){
        IStandardLcp lcp = BefRtBeanUtil.getLcpFactory().createLcp("com.inspur.gs.apporder.df.merchant.merchant.back.Merchant");
        return (com.inspur.edp.cef.entity.entity.IEntityData)MgrActionUtils.executeCustomAction(lcp,"PathHierarchyCreateSibling",dataID);
    }
    public static com.inspur.edp.cef.entity.entity.IEntityData PathHierarchyCreateChildLayer(java.lang.String dataID){
        IStandardLcp lcp = BefRtBeanUtil.getLcpFactory().createLcp("com.inspur.gs.apporder.df.merchant.merchant.back.Merchant");
        return (com.inspur.edp.cef.entity.entity.IEntityData)MgrActionUtils.executeCustomAction(lcp,"PathHierarchyCreateChildLayer",dataID);
    }
}