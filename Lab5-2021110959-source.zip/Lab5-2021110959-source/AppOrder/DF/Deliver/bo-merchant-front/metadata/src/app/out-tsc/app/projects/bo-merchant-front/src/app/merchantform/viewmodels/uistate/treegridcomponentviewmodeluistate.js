import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var TreeGridComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(TreeGridComponentViewmodelUIState, _super);
    function TreeGridComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TreeGridComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], TreeGridComponentViewmodelUIState);
    return TreeGridComponentViewmodelUIState;
}(UIState));
export { TreeGridComponentViewmodelUIState };
