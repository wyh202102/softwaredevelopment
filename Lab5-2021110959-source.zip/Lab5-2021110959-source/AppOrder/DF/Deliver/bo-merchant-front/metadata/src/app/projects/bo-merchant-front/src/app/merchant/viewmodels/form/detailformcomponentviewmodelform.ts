
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '商户',
    enableValidate: true
})

@Injectable()
export class DetailFormComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'merchantName_18dfd3c7_41rb',
        name: "{{merchantName_18dfd3c7_41rb}}",
        binding: 'merchantName',
        updateOn: 'blur',
        defaultI18nValue: '供货商名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    merchantName: FormControl;

    @NgFormControl({
        id: 'merchantType_66413d1f_oewx',
        name: "{{merchantType_66413d1f_oewx}}",
        binding: 'merchantType',
        updateOn: 'change',
        defaultI18nValue: '供货商类型',
    })
    merchantType: FormControl;

    @NgFormControl({
        id: 'email_da5e2824_7pod',
        name: "{{email_da5e2824_7pod}}",
        binding: 'email',
        updateOn: 'blur',
        defaultI18nValue: '邮箱',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    email: FormControl;

    @NgFormControl({
        id: 'telephone_51dc64ef_b1um',
        name: "{{telephone_51dc64ef_b1um}}",
        binding: 'telephone',
        updateOn: 'blur',
        defaultI18nValue: '联系电话',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    telephone: FormControl;

    @NgFormControl({
        id: 'remark_755c8e46_xc4s',
        name: "{{remark_755c8e46_xc4s}}",
        binding: 'remark',
        updateOn: 'blur',
        defaultI18nValue: '备注',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    remark: FormControl;

    @NgFormControl({
        id: 'name_c0bd885f_2fj5',
        name: "{{name_c0bd885f_2fj5}}",
        binding: 'name',
        updateOn: 'blur',
        defaultI18nValue: '负责人姓名',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    name: FormControl;

}