import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/apporder/df/web/bo-merchant-front/merchantform/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "remark_2ccdd9ac_yjxo": "备注", "TextBox/remark_2ccdd9ac_yjxo/placeHolder": "", "TextBox/companyType_3dd5deb3_dlri/placeHolder": "", "TextBox/merchantType_bc79da07_02rx/placeHolder": "", "EnumField/companyType_3dd5deb3_dlri/placeHolder": "", "EnumField/companyType_3dd5deb3_dlri/enumData/qy": "企业", "EnumField/companyType_3dd5deb3_dlri/enumData/gt": "个体工商户", "EnumField/companyType_3dd5deb3_dlri/enumData/gr": "个人", "EnumField/merchantType_bc79da07_02rx/placeHolder": "", "EnumField/merchantType_bc79da07_02rx/enumData/rz": "入驻商户", "EnumField/merchantType_bc79da07_02rx/enumData/jx": "经销商", "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "page-header-toolbar": "", "button-addSibling": "新增同级", "button-addChild": "新增子级", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "button-delete": "删除", "main-container": "", "content-splitter": "", "content-tree": "", "tree-grid-component-ref": "", "content-main": "", "detail-component-ref": "", "tree-grid-component": "", "tree-grid-section": "", "Section/tree-grid-section/mainTitle": "", "Section/tree-grid-section/subTitle": "", "treeGrid": "", "merchantCode_f652b306_i1m8": "商户编号", "merchantName_e7dc959b_yzju": "商户名称", "detail-form-component": "", "detail-form-section": "", "Section/detail-form-section/mainTitle": "基本信息", "Section/detail-form-section/subTitle": "", "detail-form-layout": "", "8d8f5081-8774-4b3a-95e3-6691ebc9dc4f": "基本信息", "FieldSet/8d8f5081-8774-4b3a-95e3-6691ebc9dc4f/collapseText": "", "FieldSet/8d8f5081-8774-4b3a-95e3-6691ebc9dc4f/expandText": "", "companyType_3dd5deb3_dlri": "企业类型", "RadioGroup/companyType_3dd5deb3_dlri/qy": "企业", "RadioGroup/companyType_3dd5deb3_dlri/gt": "个体工商户", "RadioGroup/companyType_3dd5deb3_dlri/gr": "个人", "merchantType_bc79da07_02rx": "商户类型", "RadioGroup/merchantType_bc79da07_02rx/rz": "入驻商户", "RadioGroup/merchantType_bc79da07_02rx/jx": "经销商", "merchantCode_f652b306_okho": "商户编号", "TextBox/merchantCode_f652b306_okho/placeHolder": "", "merchantName_e7dc959b_d427": "商户名称", "TextBox/merchantName_e7dc959b_d427/placeHolder": "", "realName_5c5a0af4_2ijz": "真实姓名", "TextBox/realName_5c5a0af4_2ijz/placeHolder": "", "a2e8970f-edfe-47ae-8908-e856ee041426": "企业信息", "FieldSet/a2e8970f-edfe-47ae-8908-e856ee041426/collapseText": "", "FieldSet/a2e8970f-edfe-47ae-8908-e856ee041426/expandText": "", "fullName_3ec46fb5_yime": "企业全称", "TextBox/fullName_3ec46fb5_yime/placeHolder": "", "businessLicense_bc99892e_2yww": "营业执照编码", "TextBox/businessLicense_bc99892e_2yww/placeHolder": "", "03175dc4-7c95-4f69-8551-99cc8a757293": "管理员", "FieldSet/03175dc4-7c95-4f69-8551-99cc8a757293/collapseText": "", "FieldSet/03175dc4-7c95-4f69-8551-99cc8a757293/expandText": "", "telephone_2d279712_wt5c": "联系电话", "TextBox/telephone_2d279712_wt5c/placeHolder": "", "email_6929e564_fodd": "邮箱", "TextBox/email_6929e564_fodd/placeHolder": "" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/apporder/df/web/bo-merchant-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "merchantform/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
