import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'id',
            name: "{{id_0c005673_8bk3}}",
            binding: 'id',
            updateOn: 'blur',
            defaultI18nValue: '主键',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "id", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantName',
            name: "{{merchantName_d70bde2a_3lsy}}",
            binding: 'merchantName',
            updateOn: 'blur',
            defaultI18nValue: '商户名称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "merchantName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantType',
            name: "{{merchantType_b334a325_5azc}}",
            binding: 'merchantType',
            updateOn: 'change',
            defaultI18nValue: '商户类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "merchantType", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '商户',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
