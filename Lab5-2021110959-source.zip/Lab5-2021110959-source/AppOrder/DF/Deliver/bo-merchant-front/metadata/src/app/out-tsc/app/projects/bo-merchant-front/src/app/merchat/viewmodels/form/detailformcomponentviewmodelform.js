import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DetailFormComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelForm, _super);
    function DetailFormComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantName_d70bde2a_sbmo',
            name: "{{merchantName_d70bde2a_sbmo}}",
            binding: 'merchantName',
            updateOn: 'blur',
            defaultI18nValue: '商户名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "merchantName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantType_b334a325_qyf8',
            name: "{{merchantType_b334a325_qyf8}}",
            binding: 'merchantType',
            updateOn: 'change',
            defaultI18nValue: '商户类型',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "merchantType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'email_e513a78a_8xvs',
            name: "{{email_e513a78a_8xvs}}",
            binding: 'email',
            updateOn: 'blur',
            defaultI18nValue: '邮箱',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "email", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'telephone_29593720_eld4',
            name: "{{telephone_29593720_eld4}}",
            binding: 'telephone',
            updateOn: 'blur',
            defaultI18nValue: '联系电话',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "telephone", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'remark_a1738acb_mcf6',
            name: "{{remark_a1738acb_mcf6}}",
            binding: 'remark',
            updateOn: 'blur',
            defaultI18nValue: '备注',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "remark", void 0);
    DetailFormComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '商户',
            enableValidate: true
        }),
        Injectable()
    ], DetailFormComponentViewmodelForm);
    return DetailFormComponentViewmodelForm;
}(Form));
export { DetailFormComponentViewmodelForm };
