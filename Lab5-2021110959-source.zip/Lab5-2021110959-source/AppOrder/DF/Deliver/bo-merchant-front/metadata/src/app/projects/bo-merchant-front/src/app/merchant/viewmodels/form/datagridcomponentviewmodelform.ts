
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '商户',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'merchantName',
        name: "{{merchantName_18dfd3c7_3ql6}}",
        binding: 'merchantName',
        updateOn: 'blur',
        defaultI18nValue: '供货商名称',
    })
    merchantName: FormControl;

    @NgFormControl({
        id: 'merchantType',
        name: "{{merchantType_66413d1f_cinb}}",
        binding: 'merchantType',
        updateOn: 'change',
        defaultI18nValue: '供货商类型',
    })
    merchantType: FormControl;

    @NgFormControl({
        id: 'remark',
        name: "{{remark_755c8e46_qyyl}}",
        binding: 'remark',
        updateOn: 'blur',
        defaultI18nValue: '备注',
    })
    remark: FormControl;

}