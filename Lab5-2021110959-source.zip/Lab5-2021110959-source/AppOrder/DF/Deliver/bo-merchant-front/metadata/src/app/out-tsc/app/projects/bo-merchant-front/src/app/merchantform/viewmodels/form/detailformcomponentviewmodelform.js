import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DetailFormComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelForm, _super);
    function DetailFormComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantName_e7dc959b_d427',
            name: "{{merchantName_e7dc959b_d427}}",
            binding: 'merchantName',
            updateOn: 'blur',
            defaultI18nValue: '商户名称',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "merchantName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantCode_f652b306_okho',
            name: "{{merchantCode_f652b306_okho}}",
            binding: 'merchantCode',
            updateOn: 'blur',
            defaultI18nValue: '商户编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "merchantCode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'companyType_3dd5deb3_dlri',
            name: "{{companyType_3dd5deb3_dlri}}",
            binding: 'companyType',
            updateOn: 'blur',
            defaultI18nValue: '企业类型',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "companyType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'merchantType_bc79da07_02rx',
            name: "{{merchantType_bc79da07_02rx}}",
            binding: 'merchantType',
            updateOn: 'blur',
            defaultI18nValue: '商户类型',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "merchantType", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'realName_5c5a0af4_2ijz',
            name: "{{realName_5c5a0af4_2ijz}}",
            binding: 'realName',
            updateOn: 'blur',
            defaultI18nValue: '真实姓名',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "realName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'fullName_3ec46fb5_yime',
            name: "{{fullName_3ec46fb5_yime}}",
            binding: 'fullName',
            updateOn: 'blur',
            defaultI18nValue: '企业全称',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "fullName", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'businessLicense_bc99892e_2yww',
            name: "{{businessLicense_bc99892e_2yww}}",
            binding: 'businessLicense',
            updateOn: 'blur',
            defaultI18nValue: '营业执照编码',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "businessLicense", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'email_6929e564_fodd',
            name: "{{email_6929e564_fodd}}",
            binding: 'email',
            updateOn: 'blur',
            defaultI18nValue: '邮箱',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "email", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'telephone_2d279712_wt5c',
            name: "{{telephone_2d279712_wt5c}}",
            binding: 'telephone',
            updateOn: 'blur',
            defaultI18nValue: '联系电话',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "telephone", void 0);
    DetailFormComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '商户',
            enableValidate: true
        }),
        Injectable()
    ], DetailFormComponentViewmodelForm);
    return DetailFormComponentViewmodelForm;
}(Form));
export { DetailFormComponentViewmodelForm };
