import * as tslib_1 from "tslib";
import { Component, Injector, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, COMMAND_HANDLERS_TOKEN, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { DetailFormComponentViewmodel } from '../../viewmodels/detailformcomponentviewmodel';
import { MerchantRepository } from '../../models/merchantrepository';
import { LangService } from '../../lang/lang-pipe';
import { DetailFormComponentViewmodelForm } from '../../viewmodels/form/detailformcomponentviewmodelform';
import { DetailFormComponentViewmodelUIState } from '../../viewmodels/uistate/detailformcomponentviewmodeluistate';
import { Edit1Handler } from '../../viewmodels/handlers/edit1handler';
import { Save1Handler } from '../../viewmodels/handlers/save1handler';
import { Cancel1Handler } from '../../viewmodels/handlers/cancel1handler';
var DetailFormComponent = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponent, _super);
    function DetailFormComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.cls = 'f-struct-wrapper ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.FieldSetTitle8d8f508187744b3a95e36691ebc9dc4f = _this.langService.transform("8d8f5081-8774-4b3a-95e3-6691ebc9dc4f", _this.lang, "基本信息");
        _this.FieldSetCollapseText8d8f508187744b3a95e36691ebc9dc4f = _this.langService.transform("FieldSet/8d8f5081-8774-4b3a-95e3-6691ebc9dc4f/collapseText", _this.lang, "");
        _this.FieldSetExpandText8d8f508187744b3a95e36691ebc9dc4f = _this.langService.transform("FieldSet/8d8f5081-8774-4b3a-95e3-6691ebc9dc4f/expandText", _this.lang, "");
        _this.FieldSetTitlea2e8970fedfe47ae8908e856ee041426 = _this.langService.transform("a2e8970f-edfe-47ae-8908-e856ee041426", _this.lang, "企业信息");
        _this.FieldSetCollapseTexta2e8970fedfe47ae8908e856ee041426 = _this.langService.transform("FieldSet/a2e8970f-edfe-47ae-8908-e856ee041426/collapseText", _this.lang, "");
        _this.FieldSetExpandTexta2e8970fedfe47ae8908e856ee041426 = _this.langService.transform("FieldSet/a2e8970f-edfe-47ae-8908-e856ee041426/expandText", _this.lang, "");
        _this.FieldSetTitle03175dc47c954f69855199cc8a757293 = _this.langService.transform("03175dc4-7c95-4f69-8551-99cc8a757293", _this.lang, "管理员");
        _this.FieldSetCollapseText03175dc47c954f69855199cc8a757293 = _this.langService.transform("FieldSet/03175dc4-7c95-4f69-8551-99cc8a757293/collapseText", _this.lang, "");
        _this.FieldSetExpandText03175dc47c954f69855199cc8a757293 = _this.langService.transform("FieldSet/03175dc4-7c95-4f69-8551-99cc8a757293/expandText", _this.lang, "");
        _this.SectiondetailformsectionMainTitle = _this.langService.transform("Section/detail-form-section/mainTitle", _this.lang, "基本信息");
        _this.SectiondetailformsectionSubTitle = _this.langService.transform("Section/detail-form-section/subTitle", _this.lang, "");
        _this.companyType_3dd5deb3_dlriEnumData = [
            {
                "name": _this.langService.transform("RadioGroup/companyType_3dd5deb3_dlri/qy", _this.lang, "企业"),
                "value": "qy"
            },
            {
                "name": _this.langService.transform("RadioGroup/companyType_3dd5deb3_dlri/gt", _this.lang, "个体工商户"),
                "value": "gt"
            },
            {
                "name": _this.langService.transform("RadioGroup/companyType_3dd5deb3_dlri/gr", _this.lang, "个人"),
                "value": "gr"
            }
        ];
        _this.merchantType_bc79da07_02rxEnumData = [
            {
                "name": _this.langService.transform("RadioGroup/merchantType_bc79da07_02rx/rz", _this.lang, "入驻商户"),
                "value": "rz"
            },
            {
                "name": _this.langService.transform("RadioGroup/merchantType_bc79da07_02rx/jx", _this.lang, "经销商"),
                "value": "jx"
            }
        ];
        _this.merchantCode_f652b306_okho_PlaceHolder = _this.langService.transform("TextBox/merchantCode_f652b306_okho/placeHolder", _this.lang, "");
        _this.merchantName_e7dc959b_d427_PlaceHolder = _this.langService.transform("TextBox/merchantName_e7dc959b_d427/placeHolder", _this.lang, "");
        _this.realName_5c5a0af4_2ijz_PlaceHolder = _this.langService.transform("TextBox/realName_5c5a0af4_2ijz/placeHolder", _this.lang, "");
        _this.fullName_3ec46fb5_yime_PlaceHolder = _this.langService.transform("TextBox/fullName_3ec46fb5_yime/placeHolder", _this.lang, "");
        _this.businessLicense_bc99892e_2yww_PlaceHolder = _this.langService.transform("TextBox/businessLicense_bc99892e_2yww/placeHolder", _this.lang, "");
        _this.telephone_2d279712_wt5c_PlaceHolder = _this.langService.transform("TextBox/telephone_2d279712_wt5c/placeHolder", _this.lang, "");
        _this.email_6929e564_fodd_PlaceHolder = _this.langService.transform("TextBox/email_6929e564_fodd/placeHolder", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusInvalidInput(verifyInformations, _this.rootElement);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    DetailFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.onFormLoad();
    };
    DetailFormComponent.prototype.ngAfterViewInit = function () {
    };
    DetailFormComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    DetailFormComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    DetailFormComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], DetailFormComponent.prototype, "cls", void 0);
    DetailFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-detailformcomponent',
            templateUrl: './detailformcomponent.html',
            styleUrls: ['./detailformcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'detail-form-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: MerchantRepository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: Form, useClass: DetailFormComponentViewmodelForm },
                { provide: UIState, useClass: DetailFormComponentViewmodelUIState },
                { provide: ViewModel, useClass: DetailFormComponentViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Edit1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Save1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: Cancel1Handler, multi: true },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            DomSanitizer,
            Injector])
    ], DetailFormComponent);
    return DetailFormComponent;
}(FrameComponent));
export { DetailFormComponent };
