
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { MerchantEntity } from './entities/merchantentity';

import { MerchantProxy } from './merchantproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/apporder/df/v1.0/merchant_frm',
    entityType: MerchantEntity
})
export class MerchantRepository extends BefRepository<MerchantEntity> {
    public name = 'MerchantRepository';

    public proxy: MerchantProxy;
    public paginationInfo = {
        MerchantEntity: {
            pageSize: 20,
        }
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(MerchantProxy, null);
    }
}