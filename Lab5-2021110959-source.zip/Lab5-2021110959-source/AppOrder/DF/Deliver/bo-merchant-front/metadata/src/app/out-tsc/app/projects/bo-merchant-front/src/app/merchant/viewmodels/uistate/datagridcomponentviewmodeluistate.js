import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var DataGridComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelUIState, _super);
    function DataGridComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DataGridComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], DataGridComponentViewmodelUIState);
    return DataGridComponentViewmodelUIState;
}(UIState));
export { DataGridComponentViewmodelUIState };
