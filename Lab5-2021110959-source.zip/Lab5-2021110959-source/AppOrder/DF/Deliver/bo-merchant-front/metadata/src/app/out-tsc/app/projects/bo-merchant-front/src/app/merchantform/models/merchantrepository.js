import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { MerchantEntity } from './entities/merchantentity';
import { MerchantProxy } from './merchantproxy';
var MerchantRepository = /** @class */ (function (_super) {
    tslib_1.__extends(MerchantRepository, _super);
    function MerchantRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'MerchantRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(MerchantProxy, null);
        return _this;
    }
    MerchantRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/apporder/df/v1.0/merchantform_frm',
            entityType: MerchantEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], MerchantRepository);
    return MerchantRepository;
}(BefRepository));
export { MerchantRepository };
