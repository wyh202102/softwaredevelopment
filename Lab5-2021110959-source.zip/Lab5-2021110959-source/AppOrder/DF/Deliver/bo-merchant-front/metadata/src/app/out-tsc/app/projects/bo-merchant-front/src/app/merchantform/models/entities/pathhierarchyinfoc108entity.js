import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var PathHierarchyInfoC108Entity = /** @class */ (function (_super) {
    tslib_1.__extends(PathHierarchyInfoC108Entity, _super);
    function PathHierarchyInfoC108Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Path',
            dataField: 'path',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'TreeInfo.Path',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], PathHierarchyInfoC108Entity.prototype, "path", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Layer',
            dataField: 'layer',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'TreeInfo.Layer',
        }),
        tslib_1.__metadata("design:type", Object)
    ], PathHierarchyInfoC108Entity.prototype, "layer", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'IsDetail',
            dataField: 'isDetail',
            originalDataFieldType: 'Boolean',
            initValue: false,
            path: 'TreeInfo.IsDetail',
        }),
        tslib_1.__metadata("design:type", Object)
    ], PathHierarchyInfoC108Entity.prototype, "isDetail", void 0);
    PathHierarchyInfoC108Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "TreeInfo",
            nodeCode: "treeInfo"
        })
    ], PathHierarchyInfoC108Entity);
    return PathHierarchyInfoC108Entity;
}(Entity));
export { PathHierarchyInfoC108Entity };
